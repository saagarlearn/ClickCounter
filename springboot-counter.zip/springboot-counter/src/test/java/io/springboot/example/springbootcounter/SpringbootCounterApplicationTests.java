package io.springboot.example.springbootcounter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCounterApplicationTests {

	@Test
	void contextLoads() {
	}

}
